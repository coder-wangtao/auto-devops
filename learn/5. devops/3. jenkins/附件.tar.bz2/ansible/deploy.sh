cd    /etc/ansible
t=`date +"%Y%m%d%H%M%S"`
echo   $t
#构建镜像
[ -f mkdir_scp_bulid.yaml ] && rm -vf  mkdir_scp_bulid.yaml
cp  mkdir_scp_bulid.yaml_orig   mkdir_scp_bulid.yaml
sed  -i   's/nginx:v20241016/nginx:v'$t'/g'    mkdir_scp_bulid.yaml
/usr/local/bin/ansible-playbook   mkdir_scp_bulid.yaml 
#导入镜像
[ -f save_scp_load.yml ] && rm -vf  save_scp_load.yml
cp  save_scp_load.yml_orig   save_scp_load.yml
sed  -i   's/nginx:v20241016/nginx:v'$t'/g'    save_scp_load.yml
sed  -i   's/nginx_v20241016/nginx_v'$t'/g'    save_scp_load.yml
/usr/local/bin/ansible-playbook   save_scp_load.yml
#启动k8s服务
[ -f  k8s_yaml/nginx_dep.yml ] && rm -vf  k8s_yaml/nginx_dep.yml
cp  k8s_yaml/nginx_dep_orig.yml   k8s_yaml/nginx_dep.yml
sed  -i   's/nginx:v20241016/nginx:v'$t'/g'   k8s_yaml/nginx_dep.yml
/usr/local/bin/ansible-playbook   start_k8s_svc.yaml
