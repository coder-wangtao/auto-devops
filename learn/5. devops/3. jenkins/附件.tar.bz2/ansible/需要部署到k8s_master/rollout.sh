#!/bin/bash
#function: 利用k8s的回滚功能进行版本回滚
vnum=`kubectl rollout history deployment nginx-dep |grep  -v  grep  |grep record |wc   -l `
echo  "vnum=$vnum"
prev=$(($vnum-1))
echo "prev=$prev"
if [ $vnum -ge 2 ];then
        revision=`kubectl rollout history deployment nginx-dep |grep  -v  grep  |grep record  |tail  -n  2 |head   -n  1 | awk '{print $1}'`
        echo  "revision=$revision"
        kubectl rollout undo deployment nginx-dep --to-revision=$revision
else
	echo "历史版本就一个，无法回滚"
fi
